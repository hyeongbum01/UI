// mainslide
var i2 = 0;
var sp2 = 3000;
setInterval(function () {
    $("#slide>ul>li").eq(i2).siblings().css({
        'left': '100%'
    });
    $("#slide>ul>li").eq(i2).animate({
        "left": "-100%"
    }, sp2 - 2000, function () {
        $(this).css({
            'left': '100%'
        });
    });
    if (i2 >= $("#slide>ul>li").length - 1) {
        i2 = 0;
    } else {
        i2++;
    }
    $("#slide>ul>li").eq(i2).animate({
        "left": "0"
    }, sp2 - 2000);


}, sp2);

// mainslide
// subslide
var i = 0;
var sp = 1500;
setInterval(function () {
    $("#subslide>ul>li").eq(i).siblings().css({
        'left': '100%'
    });
    $("#subslide>ul>li").eq(i).animate({
        "left": "-100%"
    }, sp, function () {
        $(this).css({
            'left': '100%'
        });
    });
    console.log(i);
    if (i >= $("#subslide>ul>li").length - 1) {
        i = 0;
    } else {
        i++;
    }
    $("#subslide>ul>li").eq(i).animate({
        "left": "0"
    }, sp);


}, sp + 2500);
// subslide


